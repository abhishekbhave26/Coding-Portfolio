For Task 1  Use proj1.1.py
For Task 2  Use proj1.2.py
For Task 3  Set A Use proj1.3.1.py and template as template1.png
For Task 3  Set B Use proj1.3.2.py and imread all temp1.png,temp2.png,temp3.png files