This file contains some python code I wrote for the hangman game -https://en.wikipedia.org/wiki/Hangman_(game).
This game can be played just by running the python script on the command  prompt. 